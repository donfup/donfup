%DK_ICU = load('danish_ICU_data.mat');
%%
clear
%% This is the data loading for ICU
tic
danish_ICU_data = xlsread('DK_Data.xlsx');
danish_ICU_data = danish_ICU_data(1,:); %ICU DATA is contained within 1st row of the .xlsx-file
save('danish_ICU_data.mat','danish_ICU_data');
load 'danish_ICU_data.mat';


%% This is the data loading for hosp_data

danish_hosp_data = xlsread('DK_Data.xlsx');
danish_hosp_data = danish_hosp_data(2,:);
save('danish_hosp_data.mat','danish_hosp_data');
load('danish_hosp_data.mat');

%% This is the data loading for death_data

danish_death2_acc_data = xlsread('DK_Data.xlsx');
danish_death2_acc_data = danish_death2_acc_data(3,:);
save('danish_death2_acc_data.mat','danish_death2_acc_data');
load('danish_death2_acc_data.mat');


toc