close all 
clear all

tic

%% Version 157
% Frederik v158: Try to fit parameters such as x, mut_scale and mitigation.
% Frederik v157: Simulation is continued until 18th of April 2022.
% Parameters such as mut, mitigation and no. of days antal dage ved +/- needs adjustment!
% Frederik v156: Data from beginnning of pandemic until 18.4.2022 happens by script "DK_DATA". 
% Frederik: New in v155: R_asymp + R_symp is joined to R_join,
% Xi_join and now includes R_t instead of R_0.
% Steen Rasmussen, Michael S. Petersen and Morten W.N. J�rgensen 
% Build on previous version by Steen Rasmussen and Michael S. Petersen

% v2 is a version where the out flow (Gamma) from the symptomatic infection
% population is disagregated having a 10 days period for the fraction of
% the population not going to the hospital, and 7 days for the fraction of
% the population going to the hospital

%% Remember to switch this when using PC or MAC %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n=1;        % n=0 for PC and n=1 for MAC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Age distribution in Denmark
% https://www.statista.com/statistics/570654/total-population-in-denmark-
% by-age/
%           combined with
% Age dependent hospitalization fractions 
% Ferguson et al.(2020), p5, table 1
A0019=1.3/5.83;             % procentage of pop age 00-19 and their
H_frac0019=(0.1+0.3)/2;     % average hospitalization fraction
A2039=1.47/5.83;            % procentage of pop age 20-39 and their
H_frac2039=(1.2+3.2)/2;     % average hospitalization fraction
A4059=1.56/5.83;            % procentage of pop age 40-49 and their
H_frac4059=(4.9+10.2)/2;    % average hospitalization fraction
A6079=1.23/5.83;            % procentage of pop age 60-79 and their
H_frac6079=(16.6+24.3)/2;   % average hospitalization fraction
A80up=0.27/5.83;            % procentage of pop age 80-up and their
H_frac80up=27.3;            % average hospitalization fraction
%% Age weighted hospitalization fraction 
hospFrac = (A0019*H_frac0019 + ...
A2039*H_frac2039 + ...
A4059*H_frac4059 + ...
A6079*H_frac6079 + ...
A80up*H_frac80up)/100; % [no unit]
% It is assumed that all population groups are equally susceptible for 
% infection. Is that a reasonable assumption? 

%% hospFrac calculated above = 
% hospitalized fraction of symptomatic infected age adjusted  [no unit]
hospFracAdjust = 1.0; %1.7; % 1.0; %0.90;      % if additional age adjust. is needed
hospFrac = hospFracAdjust*hospFrac; % adjusted hospitalized fraction


%% Population constants 
N_0 = 5.82*10^6;        % Total population in Denmark           [people]
N_S = N_0;          % Susceptible population in Denmark      [people]
% Diamond Princess only had 20% infeceted where only half of the 
% infeced had symptoms
%
%% Beta infection values

sympFrac = 0.16;     % Infected fraction with symptoms [no unit]

betaSymp0 = 1.1; %1.13; %1.09; %1.044; %1.166; % 0.97;% 1.0; % 1.09; %1.0841; % 1.36  (1.39 gamma = 8)

Zeta = 0.275/0.89;  % Keeps the relation fixed between the betas

Tau = 0.3;          % 1.5/5 days of infectiion for betaInc

betaAsymp0 = Zeta*betaSymp0;


betaI_S = (0.5+1)/5*1.00;    % Relative attack for incubated symptomatic
betaI_A = (0.16+0.32)/5; % Relative attack for incubated asymptomatic

betaInc0 = (Tau*betaSymp0/0.89)*(sympFrac+(1-sympFrac)*Zeta);

betaI_Str = betaI_S*0.01;   %  beta values for infected and tracked populace set to non zero?
betaI_Atr = betaI_A*0.01;

testcapacity=50000;

%% Temporal forcing of beatSymp(t) due to shotdown of country (S-curve)
betaSymp_low = 0.04*betaSymp0; % 0.01 %0.0682 0.032 %0.079;%0.0520;%0.001;

lockdown_coef = 0.1019;   % Lockdown constant, used to adjust the lower level
                        % of the lockdown. 

betaInc_low = lockdown_coef*betaInc0;
betaAsymp_low = lockdown_coef*betaAsymp0; % 0.11

% Time between start of pandemic simulation and first hospital data
displace_period = 14; %12    
                            % 11 ~ Feb. 27 start of pandemic simulation
                            % 12 ~ Feb. 26 ...
                            % 13 ~ Feb. 25 ...
                            % 14 ~ Feb. 24
                            % 15 ~ Feb. 23
                            % 16 ~ Feb. 22
                            % Period from simulation start
                            % to hosp_data start (9/3-2020).

% Parameters for the S-curve
lockdown_mid = displace_period + 8; % = 21 ~ 17 March;
% First hospital data March 9; Announcement March 11 (Wednesday)
% Lockdown mid March 17 (Monday)
beta_rate = 0.27; %0.2;%0.1561;%0.25; %0.3; ~ 6-7 days period of lockdown

% The next two values defines the increase in betaAsymp after lockdown 
% under the assumptions that asymptomatic infected has a higher infection
% rate not knowing they are sick. The time evolution of the different betas
% can be seen by plotting plot(t,betafunct) for betaSymp 
% and plot(t,betafunctasymp) for betaAsymp. The discontinuity in the plot
% is a result of the "if else" statement (calculating the piecewise stepfunction)
% and mult

first_level = 0.2305; % 0.298; %0.24; %1.0;   % level after re-opening of country (> June 8)

%% Frequency of outbreaks is a Possion process with 
% expected X days between outbreaks => epsilon = 1/X 
X = 0; %0.033; % outbreaks/day 
epsilon = 0; %dt*X;
outbreaksize = 0; %500;
                            
%% Infection dynamics parameters 
gammaIncub = 1/5;      % 1/(incubation period)                 [1/day]
gammaAsympRec = 1/10;   % 1/8   % 1/(asymptomatic period)      [1/day]
gammaSympRec = 1/10; % 1/8 1/12; % 1/(symptomatic period)      [1/day]
gammaHfrac = 1/7;   % (symptomatic hospitalisation period)     [1/day]

%% Loss of immunity from R population

%Xi_symp = 1/238; % See calculation from line 625
%Xi_asymp = 1/262; % See calculation from line 625
Xi_join = 1/230;
%% Hospital
gammaH = 1/8;%1/12;      % 1/(hospital 1 treatment period)           [1/day]

%alpha1 = 0.65;%0.85;   % Fraction of hospFrac (from I_Symp) that go through
                 % hospital process. (1-alpha1) denotes the fraction of
                 % death (from hospFrac) from home and care centers
alpha2 = 0.85;%0.80;   % Fraction of I_Symp that moves directly to hospital
                 % where (1-alpha2) denotes the fraction of cases directly
                 % to ICU treatment
                 
% Fractions of movements from the H variable.
% rho_HR + rho_HICU + rho_HDd = 1
rho_HR = 0.775;%0.785;%0.75;%0.775; %0.60; %0.57; % Fractions of H to R variable. 
rho_HICU = 0.135;%0.13;%0.15;%0.135; %0.15;  % Fractions of H to ICU variable. 
rho_HDd = 0.09;%0.085;%0.10;%0.09; %0.18;    % Fractions of H to Dd variable. 

%% ICU 
gammaICU = 1/10; %1/10; %1/17%   % 1/(ICU treatment period)       [1/day]

rho_ICUH = 0.72; %0.80;     % Fraction of cases moving from ICU to H

%% Home and care center 

homecareFreq = 0.0081; %0.0127;%0.0081;   % percentage of I_symp that dies directly from
                        % home and homecare centers 
gammaM = 1/8;%1/10; 1/17; % 1/(home and care center treatment period)     [1/day]
% twice as M1 and M2
                                        
%% R_0 calculation
% R_0 is calculated using the Next Generation Method with I_incub, 
% I_asymp, I_symp as the infected subsystem.
% We need to look further into the method before concluding anything.

R_0 = betaInc0/gammaIncub + (betaAsymp0*(1-sympFrac))/gammaAsympRec ...
      + betaSymp0*sympFrac/gammaSympRec;

%% Denmark has 2.5 hospital beds pr 1000 inhabitants
% https://nyheder.tv2.dk/2020-03-17-danske-hospitaler-har-naestfaerrest-
% sengepladser-i-europa-til-gengaeld-har-vi-noget-andet
Ntot_HospitalBeds = 2.5*5.8*10^6/1000; % = 14,500 hospital beds
NtotCoronaBeds = 0.2*Ntot_HospitalBeds; % Beds available for COVID-19
% Denmark has 900 ICU available for COVID-19 patients. However, only 2/3
% of physical capacity is availble due to personal/staff limitations.
% Ref: ef: SSI.
NtotICU = 600;

%% Initial condination for state variables 
initial_S = N_S - 690.0;  % Initial susceptiple population [people]
initial_Iincub = 690.0;   % Initial incubation population [people]
initial_Iasymp = 0.0;     % Initial asymptomatic population [people]
initial_Isymp = 0.0;      % Initial symptomatic population [people]
initial_itr = 0.0;        % Initial tracked aymptomatic population
%initial_R_asymp = 0.0;   % Initial recovered asymptomatic population [people]
%initial_R_symp = 0.0;    % Initial recovered symptomatic population [people]
%initial_R_all = 0.0;     % Initial total recovered population [people]
initial_R_join = 0.0;     % Initial recovered / vaccinated population [people]
initial_H = 0.0;          % Initial hopsitalized population [people]
initial_H_accum = 0.0;    % Initial accumulated hospitalized population [people]
initial_ICU = 0.0;        % Initial ICU1 population [people]
initial_ICU_accum = 0.0;  % Initial accumulated ICU population [people]
initial_M = 0.0;          % Initial M home+care cntr population [people]
initial_Dead_H = 0.0;     % Initial dead population from H [people]
initial_Dead_M = 0.0;     % Initial dead population from M[people]

%% The Solving Loop
% The numerical method used to solve the SEIR-system is a forward euler. 
% The solver is found in the file SEIR19.m and should be placed in the 
% same workdirectory as this script. dt is fixed as 0.1, and can be changed
% in the SEIR19.m-file. Simulation is with 
% continous change in beta as a decreasing logistic function. 

tend =  776;     % Number of days until simulation ends [days]
                 % Start dato er 9. marts 2020 og slutdato er 18 april 2022??
                 % 776 dage
[t, S, I_incub, I_asymp, I_symp, R_join, H, H_accum ...
       , ICU, ICU_accum, M, Dead_H, Dead_M ...
       , betafunct, betafunctasymp, betafunctinc] ...
       = SEIRS_v158_func(tend, N_S, initial_S, initial_Iincub, initial_Iasymp ...
       , initial_Isymp, initial_R_join, initial_H, initial_H_accum ...
       , initial_ICU, initial_ICU_accum, initial_M, initial_Dead_H, initial_Dead_M ...
       , betaSymp0, betaAsymp0, betaInc0, betaI_S, betaI_A ...
       , betaSymp_low, betaAsymp_low, betaInc_low, beta_rate, lockdown_mid, first_level ...
       , gammaIncub, gammaAsympRec, gammaSympRec, gammaHfrac ...
       , gammaH, gammaICU, gammaM ...
       , rho_HR, rho_ICUH, rho_HICU, rho_HDd ...
       , Xi_join, sympFrac, hospFrac, homecareFreq, alpha2, displace_period ...
       , X, epsilon, outbreaksize);

   %% Control conservation of the system and calculation of total cases

Ntot = S + I_incub + I_asymp + I_symp + R_join + H + ICU ...
       + M + Dead_H + Dead_M; %R_a og R_s burde vel v�re R_join?
   
R = R_join;

Dead = Dead_H + Dead_M;

pop_check = Ntot(1) - Ntot(end)

% Total current hospitalized cases
Htot = H + ICU;
% Total accumulated hospitalized cases
Haccum = H_accum; 
Haccum1425 = H_accum(1425);
% Total accumulated ICU cases
ICUaccum = ICU_accum;
ICUaccum1425 = ICU_accum(1425);
% Total accumulated home and care center cases
Maccum = M;

R_tot = R_join;


%% Load and fit the historical data to simulation
% This section fits the danish historical data to the simulation time
% depending on the displace_period parameter. Note that the homecare data
% is only update once a week (every 7th day) starting march 10.
% Hospitalization data starts on march 9, and ICU and death data on march
% 11.
  
load danish_hosp_data.mat
load danish_death2_acc_data.mat
load danish_ICU_data.mat

len_hosp_data = length(danish_hosp_data);
len_ICU_data = length(danish_ICU_data);

% Hospitalization data %
blank1 = find(danish_hosp_data == 0);
t_cur_h = [t(1:length(danish_hosp_data))/0.1+displace_period];  
t_cur_h(blank1) = [];
t_hosp = [t_cur_h];
danish_hosp_data(blank1) = []; 

% ICU data %
blank2 = find(danish_ICU_data == 0);
t_cur_ICU = [t(1:length(danish_ICU_data))/0.1+displace_period+2];  
t_cur_ICU(blank2) = [];
t_ICU = t_cur_ICU;  % danish ICU data starts march 11
danish_ICU_data(blank2) = [];

% Cumulative Death data %
t_death = [t(1:length(danish_death2_acc_data))/0.1+displace_period+2];

% HomeCare data %
Homecare_deaths = [0 3 15 34 37 30 26 25 19 9 3 4 4 1 1 2 1 1 0 1 0 2 1 0 0]; % Ref: SSI 
accumulate_HC_death = cumsum(Homecare_deaths);


% update since march 10 every 7th day.

t_home_cur = [t(1:7:length(Homecare_deaths)*7)/0.1+displace_period+1]; % update since march 10 every 7th day. 
t_homecare = [t_home_cur];

% generate the dates for values on the first axis
t_cur_h = [t(1:len_hosp_data)/0.1+displace_period];
t_hosp_date = datetime(2020,3,9) + caldays(0:length(t_cur_h)-1); 
t_hosp_date(blank1) = [];

t_cur_ICU = [t(1:len_ICU_data)/0.1+displace_period+2];  
t_ICU_date = datetime(2020,3,11) + caldays(0:length(t_cur_ICU)-1);  % danish ICU data starts march 11
t_ICU_date(blank2) = [];

t_death_date = datetime(2020,3,11) + caldays(0:length(t_death)-1); % Danish death data starts march 11

t_homecare_date = datetime(2020,3,10) + caldays(0:7:168); % til den 25. august

t_simstart = datetime(2020,3,9) - displace_period; % Start date: february 24
t_date = t_simstart + caldays(0:length(t(1:10:end))-1); % Start date + number of iterations divided by 10, since timestep is 0.1
                                                        % so one day is 10*timestep


%% Hospital admission characterization in simulation 
%ln_lambda=log(sol(40,6)/sol(20,6))/(40-20); % slope in log(infections)
%lambda=exp(ln_lambda);      % infectious growth rate
%doubling=log(2)/ln_lambda;  % infection doubling time in days

%% Calculate the time dependent R_t-values
R0_time = (S./N_0).*(betafunctinc./gammaIncub + (betafunctasymp.*(1-sympFrac))./gammaAsympRec ...
      + betafunct.*sympFrac./gammaSympRec);


%% Plotting the results

% Define colors for plotting %

% For simulation data 
Incub_col = [0 0 1];
Asymp_col = [0 1 0];
Symp_col = [1 0 0];
R0_col = [0 0 0];

% For historical data
ICU_col = [1 0.5 0];
H_col = [1 0.2 0.2];
Death_col = [0 0 0];
DeathHC_col = [0.6 0.6 0.6];

R_anti60 = R_tot(600);
R_anti85 = R_tot(850);
R_anti90 = R_tot(900);
R_anti95 = R_tot(950);
R_anti120 = R_tot(1200);
R_anti193 = R_tot(1930);

%% One figure with all hospital and death data together with model data
% Plot same figures with dates

fig=figure(31);
set(fig,'defaultAxesColorOrder',[Symp_col; R0_col])
yyaxis left
p1=plot(t_date,betafunct(1:10:end),'color',Symp_col,"linewidth", 2);
set(p1,'linestyle','-')
hold on
p1=plot(t_date,betafunctasymp(1:10:end),'color',Asymp_col,"linewidth", 2);
set(p1,'linestyle','-')
hold on
p1=plot(t_date,betafunctinc(1:10:end),'color',Incub_col,"linewidth", 2);
set(p1,'linestyle','-')
title('Average \beta (infection) profiles over time')
xlabel('Time [days]')
ylabel('\beta s')
xlim([t_date(1) t_date(end)])
yyaxis right
plot(t_date,R0_time(1:10:end),'--','color',R0_col,"linewidth", 2)
ylabel('$\mathcal{R}_t$','interpreter','latex')
leg1=legend("$\beta_{symp}$","$\beta_{asymp}$","$\beta_{inc}$","$\mathcal{R}_t$");
set(leg1,'Interpreter','latex')
set(gcf,'position',[400,400,700,350])
print("ShutDownProfiles_date","-dpng")
fig31 = figure(31);
fig31.Renderer = 'Painters';
print("ShutDownProfiles_date","-dpdf")
movefile ShutDownProfiles_date.pdf Results_v1
movefile ShutDownProfiles_date.png Results_v1 
 
% figure(41)
% AllInf_data = [I_incub; I_asymp; I_symp; R_asymp; R_symp];
% plot(t_date,I_incub(1:10:end),'color',Incub_col,"linewidth", 2)
% hold on
% plot(t_date,I_asymp(1:10:end),'color',Asymp_col,"linewidth", 2)
% plot(t_date,I_symp(1:10:end),'color',Symp_col,"linewidth", 2)
% plot(t_date,R_asymp(1:10:end),'--','color',Asymp_col,"linewidth", 2)
% plot(t_date,R_symp(1:10:end),'--','color',Symp_col,"linewidth", 2)
% plot(t_date,R_tot(1:10:end),'--k',"linewidth",2)
% 
% legend('I_{incub}','I_{asymp}','I_{symp}','R_{asymp}','R_{symp}','R_{tot}')
% legend('Location','SouthEastOutside')
% title('Infection Dynamics')
% xlabel('Time [days]')
% ylabel('Population Size')
% xlim([t_date(1) t_date(end)])
% print("InfectionDynamic_date","-dpng")


% figure(42)
% 
% AllInf_data = [I_incub; I_asymp; I_symp; R_asymp; R_symp];
% semilogy(t_date,I_incub(1:10:end),'color',Incub_col,"linewidth", 2)
% hold on
% semilogy(t_date,I_asymp(1:10:end),'color',Asymp_col,"linewidth", 2)
% semilogy(t_date,I_symp(1:10:end),'color',Symp_col,"linewidth", 2)
% semilogy(t_date,R_asymp(1:10:end),'--','color',Asymp_col,"linewidth", 2)
% semilogy(t_date,R_symp(1:10:end),'--','color',Symp_col,"linewidth", 2)
% semilogy(t_date,R_tot(1:10:end),'--k',"linewidth",2)
% 
% legend('I_{incub}','I_{asymp}','I_{symp}','R_{asymp}','R_{symp}','R_{tot}')
% legend('Location','SouthEastOutside')
% title('Infection Dynamics')
% xlabel('Time [days]')
% ylabel('Population Size')
% xlim([t_date(1) t_date(end)])
% 
% dim = [0.4 0.60 0.2 0.3];
% str = {sprintf('betaSymp1 [symptomatic infections/day]=%0.4G',betaSymp0)};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
% 
% dim = [0.4 0.54 0.2 0.3];
% str = {sprintf('betaAsymp1 [asymptomatic infections/day]=%0.4G',betaAsymp0)};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
% 
% dim = [0.4 0.48 0.2 0.3];
% str = {sprintf('betaInc1 [incubation infections/day]=%0.4G',betaInc0)};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
% 
% dim = [0.4 0.42 0.2 0.3];
% str = {sprintf('R_{anti}60, 95, 193 = %0.4G, %0.4G, %0.4G',R_anti60,R_anti95,R_anti193)};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
% 
% dim = [0.4 0.34 0.2 0.3];
% str = {sprintf('Xi_{asymp} [immunological memory, days]=%0.4G',1/Xi_asymp)};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
% 
% dim = [0.4 0.28 0.2 0.3];
% str = {sprintf('Xi_{symp} [immunological memory, days]=%0.4G',1/Xi_symp)};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
% 
% print("Log_InfectionDynamic_date","-dpng")


%% One figure with all hospital and death data together with model data

figure(50)
plot(t_date,Htot(1:10:end),'color',H_col);
hold on
plot(t_date,ICU(1:10:end),'color',ICU_col);
hold on
plot(t_date,Dead(1:10:end),'color',Death_col);
hold on
p=plot(t_hosp_date,danish_hosp_data,'*','color',H_col, "MarkerSize", 3);
hold on
p=plot(t_ICU_date,danish_ICU_data,'*','color',ICU_col, "MarkerSize", 3);
p=plot(t_death_date,danish_death2_acc_data,'*','color',Death_col, "MarkerSize", 3);
legend('H_{tot}','ICU','Dead_{tot}', 'H_{tot}','ICU','Dead_{tot}')
legend('Location','NorthWest')
title('Hospital Dynamics & Deaths')
xlabel('Time [days]')
ylabel('Population Size')
xlim([t_date(1) t_date(end)]) %t_date(196)])
set(gcf,'position',[400,400,700,350])
print("Hosp_Home_Dyn_Data_date","-dpng")
fig50 = figure(50);
fig50.Renderer = 'Painters';
print("Hosp_Home_Dyn_Data_date","-dpdf")
movefile Hosp_Home_Dyn_Data_date.pdf Results_v1
movefile Hosp_Home_Dyn_Data_date.png Results_v1

figure(51)
semilogy(t_date,Htot(1:10:end),'color',H_col);
hold on
semilogy(t_date,ICU(1:10:end),'color',ICU_col);
hold on
semilogy(t_date,Dead(1:10:end),'color',Death_col);
hold on
semilogy(t_date,Dead_M(1:10:end),'color',DeathHC_col);
hold on
p=semilogy(t_hosp_date,danish_hosp_data,'*','color',H_col, "MarkerSize", 3);
hold on
p=semilogy(t_ICU_date,danish_ICU_data,'*','color',ICU_col, "MarkerSize", 3);
p=semilogy(t_death_date,danish_death2_acc_data,'*','color',Death_col, "MarkerSize", 3);
p=semilogy(t_homecare_date,accumulate_HC_death,'*','color',DeathHC_col, "MarkerSize", 3);

legend('H_{tot}','ICU','Dead_{tot}','Dead_{hc}')
legend('Location','SouthEastOutside')
title('Hospital Dynamics & Deaths')
xlabel('Time [days]')
ylabel('Population Size')
xlim([t_date(1) t_date(end)])
ylim([0.1 inf])
print("Log_Hosp_Home_Dyn_Data_date","-dpng")
movefile Log_Hosp_Home_Dyn_Data_date.png Results_v1

% figure(52)
% p=plot(t_hosp_date,danish_hosp_data,'*','color',H_col, "MarkerSize", 3);
% hold on
% p=plot(t_ICU_date,danish_ICU_data,'*','color',ICU_col, "MarkerSize", 3);
% p=plot(t_death_date,danish_death2_acc_data,'*','color',Death_col, "MarkerSize", 3);
% legend('H_{tot}','ICU','Dead_{tot}')
% legend('Location','NorthWest')
% title('Hospital Data & Deaths')
% xlabel('Time [days]')
% ylabel('Population Size')
% xlim([t_date(1) t_date(end)]) %t_date(196)])
% set(gcf,'position',[400,400,700,350])
% print("Hosp_Home_Data_date","-dpng")
% fig52 = figure(52);
% fig52.Renderer = 'Painters';
% print("Hosp_Home_Data_date","-dpdf")
% movefile Hosp_Home_Data_date.pdf Results_v1
% movefile Hosp_Home_Data_date.png Results_v1

%% Steady state calculation
% Load data
% THIS SECTION IS NOT UPDATED WITH CORRECT DATES %
corona_data = xlsread('CoronaData.xlsx'); % Gets datasheet from the excel file
H_i = corona_data(:,4); % Load number of hospitalized per day
infected_tested = corona_data(:,5);

% By looking at the data, we can assume three steady state periods
first_period = H_i(1:94); % First period goes from September 1 to December 3
second_period = H_i(95:126); % Second period goes from December 4 to January 4
third_period = H_i(127:156); % Third period goes from January 5 to February 3

time_first_period = t_date(183:276);
time_second_period = t_date(278:309);
time_third_period = t_date(310:339);
time_tested = t_date(191:346);

I_tot = I_symp(1:10:end)+I_asymp(1:10:end)+I_incub(1:10:end); % Total infected

first_period_function = 1764+63*first_period+336+12*first_period+2094+37*first_period; % Calculated steady state functions
second_period_function = 15367+63*second_period+2927+12*second_period+18293+37*second_period;
third_period_function = 8898+63*third_period+1695+12*third_period+10594+37*third_period;

%Datapoints for steady state
average_infected = [13280,19397,38402,112616]; % Average infected every month from September to December for Steady State
time_average_infected = [t_date(205),t_date(235),t_date(266),t_date(296)]; % Time for the above, every points fits the middle day for each month

%Datapoints for the model
model_average_infected = [sum(I_tot(191:220))/30,sum(I_tot(221:251))/31,sum(I_tot(252:281))/30,sum(I_tot(282:312))/31];

% Average contacted by the STPS per month
STPS_average_contacted = [558,624,1240,3217];

% % Average of detected infected per month
% SSI_average_tested = [387,636,1151,2704];
% 
% figure(64)
% plot(t_date,I_tot,'color',Symp_col,"linewidth", 2)
% hold on
% plot(time_tested,infected_tested,"linewidth",2)
% plot(time_first_period,first_period_function,"linewidth", 2,"color",[0.9290 0.6940 0.1250])
% scatter(time_average_infected,average_infected,'filled','MarkerEdgeColor',[0 0.4470 0.7410],'MarkerFaceColor',[0 0.4470 0.7410])
% scatter(time_average_infected,model_average_infected,'filled')
% scatter(time_average_infected,STPS_average_contacted,'filled')
% scatter(time_average_infected,SSI_average_tested,'filled')
% plot(time_second_period,second_period_function,"linewidth", 2,"color",[0.9290 0.6940 0.1250])
% plot(time_third_period,third_period_function,"linewidth", 2,"color",[0.9290 0.6940 0.1250])
% legend('I_{sum}','I_{positive tested}','I_{steady state approximation}','I_{average, Steady State}','I_{average, Model}'...
%     ,'I_{STPS, contact to infected}','I_{SSI, average tested}')
% legend('Location','SouthEastOutside')
% title('Steady state')
% xlabel('Time [days]')
% ylabel('Population Size')
% xlim([t_date(1) t_date(end)])
% set(gcf,'position',[400,400,700,350])
% print("Hosp_Home_Dyn_Data_date","-dpng")
% fig64 = figure(64);
% fig64.Renderer = 'Painters';
% hold off
% print("Steady_state","-dpng")
% 
% figure(65)
% scatter(time_average_infected,average_infected,'filled')
% hold on
% scatter(time_average_infected,model_average_infected,'filled')
% scatter(time_average_infected,STPS_average_contacted,'filled')
% legend('I_{average, Steady State}','I_{average, Model}','I_{STPS, contact to infected and close contacts}')
% legend('Location','SouthEastOutside')
% title('Infection tracing')
% xlabel('Time [days]')
% ylabel('Population Size')
% grid on
% xlim([t_date(1) t_date(end)])
% set(gcf,'position',[400,400,700,350])
% print("Hosp_Home_Dyn_Data_date","-dpng")
% fig65 = figure(65);
% fig65.Renderer = 'Painters';
% hold off
% print("Infection_traced","-dpng")

%% Infection tracing efficiency

%Load data: the time-array is 

daily_infected = xlsread('Dagligt_smittede.xlsx'); % load data
daily_infected_traced = daily_infected(:,1+n); % Loads daily infected from July 1 to March 4
daily_infected_traced = daily_infected_traced.'; % Transposing
daily_positive_percentage = daily_infected(:,2+n); % Daily positive percentage
daily_positive_percentage = daily_positive_percentage.'; % Transposing
daily_tested_number = daily_infected(:,4+n); % Total tested for covid-19
daily_tested_number = daily_tested_number.'; % Transposing

% Fixes the time-array for plotting the datapoints and find index of 1st
% july 
t_date_dagligtsmittede = datetime(2020,7,1) + caldays(0:length(daily_infected(:,4))-1);      %her

t_date_1stjuly = find(t_date == t_date_dagligtsmittede(1));
t_date_endofdata = find(t_date == t_date_dagligtsmittede(end));

t_date_1stjuly_index = t_date_1stjuly/0.1;
t_date_endofdata_index = t_date_endofdata/0.1;

I_tot = I_symp(1:10:end)+I_asymp(1:10:end)+I_incub(1:10:end); % Total infected
I_sympX = I_symp(1:10:end);

I_IncubRateIn = (betafunctinc(t_date_1stjuly_index:10:t_date_endofdata_index).*I_incub(t_date_1stjuly_index:10:t_date_endofdata_index)...
    + betafunctasymp(t_date_1stjuly_index:10:t_date_endofdata_index).*I_asymp(t_date_1stjuly_index:10:t_date_endofdata_index)...
    +betafunct(t_date_1stjuly_index:10:t_date_endofdata_index).*I_symp(t_date_1stjuly_index:10:t_date_endofdata_index))...
    .*(S(t_date_1stjuly_index:10:t_date_endofdata_index)./N_0); % Accumulated incubated people

I_sympRateIn = I_incub(1:10:end)*gammaIncub*sympFrac;
I_asympRateIn = I_incub(1:10:end)*gammaIncub*(1 -sympFrac);
% I_tot = I_symp(1:10:end); % I_symp infected only
I_new_model = I_incub(t_date_1stjuly_index:10:t_date_endofdata_index)*gammaIncub; % I_incub*gamma_incub, see reference

f1 = 10/11.5;
f2 = 1/11.5;
rho = 0.16;

DT_incub = (daily_infected_traced./I_IncubRateIn);
DT_late = (((f1*rho).*I_IncubRateIn)+f2*(daily_infected_traced-((f1*rho).*I_IncubRateIn)))./I_IncubRateIn;
DT_avg = (DT_incub+DT_late)/2;
DT_inf = (f1*daily_infected_traced)./(I_incub(t_date_1stjuly_index:10:t_date_endofdata_index)*gammaIncub);
DT_real = (daily_infected_traced(6:247)./I_IncubRateIn(1:242));

% figure(100)
% plot(t_date_dagligtsmittede,DT_avg*100,'LineWidth',2,'color',[0.5 0.5 0.5])             %her
% title('Daily testing efficiencies')
% ylim([0 190])
% xlabel('Time')
% ylabel('Percentage identified infected')
% set(gcf,'position',[400,400,700,350])
% xlim([t_date_dagligtsmittede(1) t_date_dagligtsmittede(end)])
% hold on
% plot(t_date_dagligtsmittede,DT_late*100,'LineWidth',1.5,'color',[0.6350 0.0780 0.1840])
% plot(t_date_dagligtsmittede,DT_incub*100,'LineWidth',1.5,'color',[0 0.4470 0.7410])
% plot(t_date_dagligtsmittede,DT_inf*100,'LineWidth',1.5,'color',[0.4660 0.6740 0.1880])
% plot(t_date_dagligtsmittede(1:242),DT_real*100,'LineWidth',1.5,'color','black')
% legend('DT_{avg}(t)',...
%     'DT_{late}(t)','DT_{incub}(t)','DT_{inf}(t)','DT_{real}(t)')
% print("Percentage","-dpng")
% fig100 = figure(100);
% fig100.Renderer = 'Painters';
% print("Testing_efficiency","-dpdf")
% movefile Percentage.png Results_v1
% movefile Testing_efficiency.pdf Results_v1
% hold off

%%

% figure(200)
% plot(t_date_dagligtsmittede(1:242),DT_real*100,'LineWidth',1.5,'color','black')
% ylim([0 200])
% xlabel('Time')
% ylabel('Percentage identified infected')
% set(gcf,'position',[400,400,700,350])
% xlim([t_date_dagligtsmittede(1) t_date_dagligtsmittede(end)])
% print("Percentage_real","-dpng")
% fig200 = figure(200);
% fig200.Renderer = 'Painters';
% print("Testing_efficiency_real","-dpdf")
% movefile Percentage_real.png Results_v1
% movefile Testing_efficiency_real.pdf Results_v1

%% Calculation of average testing efficiency

% Inclusion of the high efficiency
efficiency_high_avg = (sum(DT_avg)/length(DT_avg))*100;
efficiency_high_incub = (sum(DT_incub)/length(DT_incub))*100;
efficiency_high_late = (sum(DT_late)/length(DT_late))*100;
efficiency_high_inf = (sum(DT_inf)/length(DT_inf))*100;
efficiency_high_real = (sum(DT_real)/length(DT_real))*100

% Exclusion of the high efficiency (from August 24th)
efficiency_avg = (sum(DT_avg(55:1:end))/length(DT_avg(55:1:end)))*100;
efficiency_incub = (sum(DT_incub(55:1:end))/length(DT_incub(55:1:end)))*100;
efficiency_late = (sum(DT_late(55:1:end))/length(DT_late(55:1:end)))*100;
efficiency_inf = (sum(DT_inf(55:1:end))/length(DT_inf(55:1:end)))*100;
efficiency_real = (sum(DT_real(55:1:end))/length(DT_real(55:1:end)))*100

% From Sep 1 to March 4
efficiency_avg = (sum(DT_avg(191:1:end))/length(DT_avg(191:1:end)))*100;

%% Figure 102+104

y1 = I_tot(t_date_1stjuly:t_date_endofdata);
y2 = I_new_model;
y3 = daily_infected_traced;
y4 = I_IncubRateIn;

% figure(106)
% title('Infected and Traced')
% plot(t_date_dagligtsmittede,y2,'LineWidth',3,'color','black')
% set(gcf,'position',[400,400,700,350])
% addaxis(t_date(t_date_1stjuly:t_date_endofdata),y1,'LineWidth',2,'color',[0.6350 0.0780 0.1840]);
% addaxis(t_date_dagligtsmittede,y4,[0 17500],'LineWidth',2,'color',[0 0.4470 0.7410])
% addaxis(t_date_dagligtsmittede,y3,[0 6000],'o','MarkerFaceColor',[0.4660 0.6740 0.1880],'color'...
%     ,[0.4660 0.6740 0.1880],'MarkerSize',2.7);
% addaxislabel(2,'Infected population');
% addaxislabel(1,'Simulated Daily Infection Rate');
% addaxislabel(4,'Identified infected population');
% addaxislabel(3,'Rate of Incubation');
% legend('Simulated Daily Infection Rate','Simulated Total Infected Population','Simulated Daily Incubation Rate','Daily Identified Infected Population'...
%     ,'Location','NorthWest');
% xlim([t_date(t_date_1stjuly) t_date(t_date_endofdata)])
% print("Infected_traced_rate","-dpng")
% fig106 = figure(106);
% fig106.Renderer = 'Painters';
% print("Infected_traced_rate","-dpdf")
% movefile Infected_traced_rate.pdf Results_v1
% movefile Infected_traced_rate.png Results_v1
% 
% 
% figure(108)
% title('Infected and Traced')
% plot(t_date_dagligtsmittede,y2,'LineWidth',3,'color','black')
% set(gcf,'position',[400,400,700,350])
% addaxis(t_date_dagligtsmittede,y4,[0 17500],'LineWidth',2,'color',[0 0.4470 0.7410])
% addaxis(t_date_dagligtsmittede,y3,[0 6000],'o','MarkerFaceColor',[0.4660 0.6740 0.1880],'color'...
%     ,[0.4660 0.6740 0.1880],'MarkerSize',2.7);
% addaxislabel(1,'Simulated Daily Infection Rate');
% addaxislabel(3,'Identified infected population');
% addaxislabel(2,'Rate of Incubation');
% legend('Simulated Daily Infection Rate','Simulated Daily Incubation Rate','Daily Identified Infected Population'...
%     ,'Location','NorthWest');
% xlim([t_date(t_date_1stjuly) t_date(t_date_endofdata)])
% print("Infected_traced_rate_1","-dpng")
% fig108 = figure(108);
% fig108.Renderer = 'Painters';
% print("Infected_traced_rate_1","-dpdf")
% movefile Infected_traced_rate_1.pdf Results_v1
% movefile Infected_traced_rate_1.png Results_v1



%% Infected population, traced infected, positive percentage and tested population

y1 = I_tot(t_date_1stjuly:t_date_endofdata);
y2 = daily_infected_traced;
y3 = daily_positive_percentage;
y4 = daily_tested_number;

% figure(105)
% title('')
% plot(t_date(t_date_1stjuly:t_date_endofdata),y1,'LineWidth',2,'color','black');
% set(gcf,'position',[400,400,700,350])
% addaxis(t_date_dagligtsmittede,y2,[0 4500],'-','LineWidth',2,'MarkerSize',2,'color',[0.4660 0.6740 0.1880]);
% addaxis(t_date_dagligtsmittede,y3,[0 5],'-','LineWidth',2,'MarkerSize',2,'color',[0.6350 0.0780 0.1840]);
% addaxis(t_date_dagligtsmittede,y4,[0 200000],'-','LineWidth',2,'MarkerSize',2,'color',[0 0.4470 0.7410]);
% addaxislabel(1,'Infected population');
% addaxislabel(2,'Identified infected population');
% addaxislabel(3,'Positive percentage');
% addaxislabel(4,'Tested population');
% legend('Infected population','Identified infected population','Positive percentage','Tested population','Location','NorthWest');
% xlim([t_date(t_date_1stjuly) t_date(t_date_endofdata)])
% print("Infected_traced_positive_and_tested","-dpng")
% fig105 = figure(105);
% fig105.Renderer = 'Painters';
% print("Infected_traced_positive_and_tested","-dpdf")
% movefile Infected_traced_positive_and_tested.pdf Results_v1
% movefile Infected_traced_positive_and_tested.png Results_v1

%%

% Defines different time vectors for the different datasets
%t_date_weeks1 = [t_date(95),t_date(196),t_date(301)];
%t_date_weeks2 = t_date(225:7:372);
%t_date_weeks3 = t_date(204:7:309);
t_date_weeks1 = [datetime(2020,5,28),datetime(2020,9,6),datetime(2020,12,20)];  % her
t_date_weeks2 = datetime(2020,10,5) + caldays(0:7:147);                         % her
t_date_weeks3 = datetime(2020,9,14)+caldays(0:7:105);                           % her


% Defines immunity rate data from SSI and Bloodbank
Data2 = xlsread('CoronaDataImmunitet.xlsx');
Recovered_Blooddoner = Data2(:,2);
Recovered_Blooddoner = Recovered_Blooddoner.';
Recovered_SSI = Data2(:,3);
Recovered_SSI = Recovered_SSI(1:3);
Recovered_SSI2 = Data2(:,5);
Recovered_SSI2 = Recovered_SSI2(1:16).';

load R_tot_200
load R_tot_365

figure(67)
plot(t_date,R_tot(1:10:end),'color',[0.9290 0.6940 0.1250],"linewidth",2) 
hold on
%plot(t_date,R_tot_200(1:10:end),'color',[0.8500 0.3250
%0.0980],"linewidth",2)                                                                    %Plottet tidl. SKAL �NDRES TIL R_JOIN!!! 
%plot(t_date,R_tot_365(1:10:end),'color',[0.4660 0.6740 0.1880],"linewidth",2)
scatter(t_date_weeks1,Recovered_SSI,25,'filled','MarkerEdgeColor',[0 0.4470 0.7410],'MarkerFaceColor',[0 0.4470 0.7410])
scatter(t_date_weeks2,Recovered_Blooddoner,25,'filled','MarkerEdgeColor',[0.6350 0.0780 0.1840],'MarkerFaceColor',[0.6350 0.0780 0.1840])
scatter(t_date_weeks3,Recovered_SSI2,25,'filled','MarkerEdgeColor',[0 0.4470 0.7410],'MarkerFaceColor',[0 0.4470 0.7410])
legend('R_{join}, \xi_{join}=1/230,','R_{tot}, \xi_{symp,asmyp} = 1/200','R_{tot}, \xi_{symp,asmyp} = 1/365','R_{tot, measured, SSI}', 'R_{tot, measured, Bloodbank}','Location','northwest')
title('Prevalence of Covid-19')
xlabel('Time [days]')
ylabel('Population Size')
set(gcf,'position',[400,400,700,350])
hold off
print("Prevalence","-dpng")
fig67 = figure(67);
fig67.Renderer = 'Painters';
print("Prevalence","-dpdf")
movefile Prevalence.pdf Results_v1
movefile Prevalence.png Results_v1


% figure(68)
% scatter(t_date_weeks1,Recovered_SSI,25,'filled','MarkerEdgeColor',[0 0.4470 0.7410],'MarkerFaceColor',[0 0.4470 0.7410])
% hold on
% scatter(t_date_weeks2,Recovered_Blooddoner,25,'filled','MarkerEdgeColor',[0.6350 0.0780 0.1840],'MarkerFaceColor',[0.6350 0.0780 0.1840])
% scatter(t_date_weeks3,Recovered_SSI2,25,'filled','MarkerEdgeColor',[0 0.4470 0.7410],'MarkerFaceColor',[0 0.4470 0.7410])
% legend('R_{tot, measured, SSI}', 'R_{tot, measured, Bloodbank}','Location','northwest')
% title('Prevalence Data of Covid-19 Denmark')
% xlabel('Time [days]')
% ylabel('Population Size')
% set(gcf,'position',[400,400,700,350])
% hold off
% print("Prevalence_data","-dpng")
% fig68 = figure(68);
% fig68.Renderer = 'Painters';
% print("Prevalence_data","-dpdf")
% movefile Prevalence_data.pdf Results_v1
% movefile Prevalence_data.png Results_v1

%% Calculation of Xi-values

% Guestimates for Xi-values
Xi_sy = 1/230; % Young symptomatic
Xi_so = 1/230; % Old symptomatic
Xi_ay = 1/230; % Young asymptomatic
Xi_ao = 1/230; % Old asymptomatic

T_daily_accum = cumsum(daily_infected_traced); % 247 days in length, from July 1
R_tot_Xi = R_tot(t_date_1stjuly_index:10:t_date_endofdata_index); % 247 days in length, from July 1

R_tot_minus_iden = R_tot_Xi - T_daily_accum; % Dark number - unidentified

total_young = 0.84.*T_daily_accum + 0.9.*R_tot_minus_iden;
total_old = 0.16.*T_daily_accum + 0.1.*R_tot_minus_iden;

young_asymp = 0.9.*total_young;
young_symp = 0.1.*total_young;
old_asymp = 0.5.*total_old;
old_symp = 0.5.*total_old;

% Check for accuracy of guestimates
test_guestimates_1 = 0.11.*total_young + 0.51.*total_old;
test_guestimates_2 = 0.16.*R_tot_Xi;
accuracy_test_12 = test_guestimates_1-test_guestimates_2;
mean_guestimates = mean(accuracy_test_12); % Calculated to +/- 300 individuals

Xi_s_estimates = (young_symp./(young_symp+old_symp)).*Xi_sy + (old_symp./(young_symp+old_symp)).*Xi_so; 
Xi_a_estimates = (young_asymp./(young_asymp+old_asymp)).*Xi_ay + (old_asymp./(young_asymp+old_asymp)).*Xi_ao;
Xi_s_estimates_mean = mean(Xi_s_estimates); % Calculated to 0.0042 = 1/238.
Xi_a_estimates_mean = mean(Xi_a_estimates); % Calculated to 0.0038 = 1/263


toc
















